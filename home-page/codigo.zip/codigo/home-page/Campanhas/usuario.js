var dbCampanha = {
  dados: [
    {
      id: '1',
      titulo: 'Teste1',
      descricao: 'asjchasjkcbnlakshdbglajhscbal',
      email: '',
      telefone: '',
      endereco: '',
      historia: ''
    },
    {
      id: '2',
      titulo: 'teste2',
      descricao: 'scjahsklcbaoisdhajkscbalkshdgbçasjcnals',
      email: '',
      telefone: '',
      endereco: '',
      historia: ''
    },
    {
      id: '3',
      titulo: 'teste3',
      descricao: 'asjcbhnhalkhsbclaishbncljashb',
      email: '',
      telefone: '',
      endereco: '',
      historia: ''
    },
    {
      id: '4',
      titulo: 'teste4',
      descricao: 'scjahsklcbaoisdhajkscbalkshdgbçasjcnals',
      email: '',
      telefone: '',
      endereco: '',
      historia: ''
    },
    {
      id: '5',
      titulo: 'teste5',
      descricao: 'scjahsklcbaoisdhajkscbalkshdgbçasjcnals',
      email: '',
      telefone: '',
      endereco: '',
      historia: ''
    }
  ]
};
